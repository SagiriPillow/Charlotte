﻿_lines = False

while True:
    try:
        if _lines:
            _new_line = input(".....   ")
            if _new_line == "":
                exec(_code)
                _lines = False
            else:
                _code += _new_line
        else:
            _code = input("Code:")
            if _code == "":
                pass
            else:
                while _code[-1] == " ":
                    _code = _code[:-1]
                if _code[-1] == ":" or _code[-1] == "." or _code[-1] == "\\":
                    _long_code = _code + "\n"
                    _lines = True
                else:
                    if "=" in _code:
                        _exec(_code)
                    else:
                        try:
                            _output = eval(_code)
                        except:
                            exec(_code)
                            _output = None
                        if _output is not None:
                            print(_output)
                    
    except:
        print("Error!")
